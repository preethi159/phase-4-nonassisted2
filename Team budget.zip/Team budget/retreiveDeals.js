function retreiveDeal()
{
var obj=sessionStorage.getItem("obj");
if(obj==null)
{
    document.getElementById("out").innerHTML="Record is not there!!"
}
else
{
    let DealData=JSON.parse(obj);
    for(i=0;i<=DealData.length;i++)
    {
        let pTag=document.createElement("p");
        let ptTagValue=document.createTextNode("Budget:"+DealData[i].budget +"Project Name:"+DealData[i].project +"Expenses:"+DealData[i].expenses);
        pTag.appendChild(ptTagValue);
        document.getElementById("result").appendChild(pTag);
    }
}



}
function addDeal()
{
    var budgetValue=document.getElementById("budget").value;
    var projectName=document.getElementById("project").value;
    var expensess=document.getElementById("expenses").value;
    var obj = sessionStorage.getItem("obj");
    let deal={budget:budgetValue,project:projectName,expenses:expensess};
    if(obj==null)
    {
        dealInfo=new Array();
        dealInfo.push(deal);
        sessionStorage.setItem("obj",JSON.stringify(dealInfo));
    }
    else{
        obj = JSON.parse(obj);
        obj.push(deal);
        sessionStorage.setItem("obj",JSON.stringify(obj));
    }
    document.getElementById("budget").value=""
    document.getElementById("project").value=""
    document.getElementById("expenses").value=""
    document.getElementById("out").innerHTML="Data Added.."
}

